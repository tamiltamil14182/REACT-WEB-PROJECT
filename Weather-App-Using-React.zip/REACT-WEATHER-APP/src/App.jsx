import  { useEffect, useState } from 'react';
import './App.css';
import axios from 'axios';

function App() {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setCity(e.target.value);
  };

  useEffect(() => {
    if (!city.trim()) return; 

    const apiKey = "62113a9ca550a78678fe4feae92b67b6";
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    const getWeather = () => {
      axios
        .get(apiUrl)
        .then((response) => {
          setWeather(response.data);
          setError(null);
        })
        .catch((error) => {
          setWeather(null);
          console.error(error);
        });
    };

    const timer = setTimeout(() => {
      getWeather();
    }); 

    return () => clearTimeout(timer); 
  }, [city]); 


  return (
    <div className="App">
      <div className='content'>
      <input
        type="text"
        id="city-input"
        name="city"
        placeholder="Enter city name"
        value={city}
        onChange={handleChange}
      />

      {error && <p>{error}</p>}

      {weather && (
        <>
        <div>
          <img className='img1' src="city image.jpeg" alt="city image" />
          <h1>City : {weather.name}</h1>
        </div>

        <div>
          <img className='img2' src="broken image.jpeg" alt="broken image" />
          <h2>{weather.weather[0].description}</h2>
        </div>
         
          <div className='temp'>
          <img className='img3' src="temp image.jpg" alt="temp image" />
          <h3>Temperature: {weather.main.temp}°C</h3>
          </div>

          <div className='humi'>
          <img className='img4' src="humidity image.jpeg" alt="humidity image" />
          <h3>Humidity: {weather.main.humidity}%</h3>
          </div>
          
          <div className='wind'>
          <img className='img5' src="wind image.jpeg" alt="wind image" />
          <h3>Wind Speed: {weather.wind.speed} m/s</h3>
          </div>
        
        </>
      )}
       </div>
    </div>
  );
}

export default App;
