import { useState } from 'react';

function OddEvenPrimeNum() {
  const [count, setCount] = useState(0)
  const btnStyle = { border: "1px solid black", cursor: "pointer",margin:"10px"}

  const isPrime = (num) => {
    if (num <= 1) return false;
    for (let i = 2; i <= Math.sqrt(num); i++) {
      if (num % i === 0) {
        return false;
      }
    }
    return true;
  };
  const getListItems = () => {
    const listItems = [];
    for (let i = 1; i <= count; i++) {
      let item = "";
      let itemColor = "";

      if(isPrime(i)){
        item = `${i} : is prime`;
        itemColor = "blue";
      }
      else if(i % 2 === 0) {
        item = `${i} : is even`;
        itemColor = "green";
      }
      else if(i % 2 !== 0){
        item = `${i} : is odd`;
        itemColor = "red";
      }
      if(item !==""){
      listItems.push({ text: item, color: itemColor });
      }
    }
    return listItems;
  };

  return (
    <div>

      <div>
        <button onClick={() => setCount(count + 1)} style={btnStyle}><h1>💙</h1></button>
        <b>{count}</b>
        <button onClick={() => setCount(count - 1)} style={btnStyle}><h1>💔</h1></button>
      </div>
      <div>
        <ul>
          {getListItems().map((item, index) => (
            <li key={index} style={{ color: item.color }}>
              {item.text}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
export default OddEvenPrimeNum;