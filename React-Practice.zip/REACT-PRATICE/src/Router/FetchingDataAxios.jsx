import { useEffect,useState } from "react"
import axios from "axios"

function FetchingDataAxios() {
    const [data,setData]=useState([])
    const url="https://dummyjson.com/users"
    useEffect(()=>{
        axios.get(url)
        .then(Response=>setData(Response.data.users))
        .catch(error=>console.log(error))
    })
  return (
    <>
    <h1>Fetching Data Using Axios</h1>
    {
     data.map(ele=>{
        return <li key={ele.id}>{ele.firstName}</li>
     })
    }
    </>
  )
}

export default FetchingDataAxios