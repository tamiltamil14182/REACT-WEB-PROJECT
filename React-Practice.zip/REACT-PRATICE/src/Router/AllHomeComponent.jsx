import { Link } from 'react-router-dom';

function AllHomeComponent() {
  return (
    <div>
       <h1>Welcome to the React Components Router</h1>
      <h2>Click the Component</h2>
      <ul>
        <li><Link to="/array-data">ArrayData</Link></li>
        <li><Link to="/object-data">ObjectData</Link></li>
        <li><Link to="/image-data">ImageData</Link></li>
        <li><Link to="/circle-create">CircleCreate</Link></li>
        <li><Link to="/color-change">ColorChange</Link></li>
        <li><Link to="/text-count">TextCount</Link></li>
        <li><Link to="/array-fruits">ArrayFruits</Link></li>
        <li><Link to="/change-word-position">ChangeWordPosition</Link></li>
        <li><Link to="/dicegame">Dicegame</Link></li>
        <li><Link to="/add-new-data">AddNewData</Link></li>
        <li><Link to="/odd-even-prime-num">OddEvenPrimeNum</Link></li>
        <li><Link to="/fetching-api">FetchingAPI</Link></li>
        <li><Link to="/fetching-data-axios">FetchingDataAxios</Link></li>
        <li><Link to="/statehook-todo">StateHookTodo</Link></li>
        <li><Link to="/count-reducer">CountReducer</Link></li>
        <li><Link to="/reducerhook-todo">ReducerHookTodo</Link></li>
      </ul>
    </div>
  );
}

export default AllHomeComponent;