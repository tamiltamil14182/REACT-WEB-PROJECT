import {useReducer} from "react"

function countReducer(state,action){
    if(action.type=="inc"){
        return state + action.payload
    }
    else if(action.type=="dec"){
      return state - action.payload
    }
    else{
        return state
    }
}

function CountReducer() {
    const[count,countDispatch]=useReducer(countReducer,0)
  return (
   <>
   <h1>UseReducer()Hook</h1>
   <h1>Count : {count}</h1>
   <button onClick={()=>countDispatch({type:"inc",payload:1})}>+1</button>
   <button onClick={()=>countDispatch({type:"dec",payload:1})}>-1</button>
   <button onClick={()=>countDispatch({type:"inc",payload:10})}>+10</button>
   <button onClick={()=>countDispatch({type:"dec",payload:10})}>-10</button>
   </>  
   )
}

export default CountReducer;