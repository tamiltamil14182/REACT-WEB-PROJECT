import  { useState } from 'react';

const AddNewData = () => {
  const [data, setData] = useState([
    { id: 1, name: 'A', gender: 'male', age: 24 },
    { id: 2, name: 'B', gender: 'female', age: 20 }
  ]);
  
  const [newEntry, setNewEntry] = useState({ id: '', name: '', gender: '', age: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewEntry({ ...newEntry, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setData([...data, newEntry]);
    setNewEntry({ id: '', name: '', gender: '', age: '' });
  };

  return (
    <div>
      <h1>Task 1: Display Data</h1>
      <table border="1">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Gender</th>
            <th>Age</th>
          </tr>
        </thead>
        <tbody>
          {data.map((person) => (
            <tr key={person.id}>
              <td>{person.id}</td>
              <td>{person.name}</td>
              <td>{person.gender}</td>
              <td>{person.age}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Add New Entry</h2>
      <form onSubmit={handleSubmit}>
        <input type="number" name="id" value={newEntry.id} onChange={handleChange} placeholder="ID" required />
        <input type="text" name="name" value={newEntry.name} onChange={handleChange} placeholder="Name" required />
        <input type="text" name="gender" value={newEntry.gender} onChange={handleChange} placeholder="Gender" required />
        <input type="number" name="age" value={newEntry.age} onChange={handleChange} placeholder="Age" required />
        <button type="submit">Add</button>
      </form>
    </div>
  );
};

export default AddNewData;