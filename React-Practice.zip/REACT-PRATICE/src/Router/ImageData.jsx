import { useState } from "react";

function ImageData() {
  const [source, setSource] = useState("");
  const [isHovered, setIsHovered] = useState();

  const imgStyle = {
    border: "1px solid black", height: "20px", width: "60px", cursor: "pointer",
    backgroundColor: isHovered ? "aqua" : "transparent", margin: "10px 10px 10px 10px"
  };

  const imageContainerStyle = {
    border: "1px solid black",
    height: "150px",
    width: "300px",
    // margin: "10px auto",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
  };
  const imageStyle = {
    maxWidth: "100%",
    maxHeight: "100%",
  };
    
  return (
    <div>
      <div style={imageContainerStyle}>
        {source ?
          <img src={source} alt="player" style={imageStyle} /> :
          <h1>Display the Image</h1>
        }
      </div>
      <div>
        <button onClick={() => setSource("dhoni.jpg")} style={imgStyle}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}>DHONI</button>
        <button onClick={() => setSource("rohit.webp")} style={imgStyle}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}>ROHIT</button>
        <button onClick={() => setSource("virat.jpg")} style={imgStyle}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}>VIRAT</button>
      </div>  
   </div>
  )
}

export default ImageData;