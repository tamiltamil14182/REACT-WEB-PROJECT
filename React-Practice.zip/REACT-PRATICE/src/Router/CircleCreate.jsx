import { useState } from "react"

function CircleCreate() {
  const [circles, setCircles] = useState([])
  function createCircle() {
    let obj = {
      isSelected: false,
      id: Math.trunc(Math.random() * 100000)
    }
    setCircles([...circles, obj]) //shallow copy
  }
  function selectCircle(id) {
    let updatedCircles = circles.map(ele => {
      if (ele.id === id) {
        ele.isSelected = !ele.isSelected
      }
      return ele
    })
    setCircles(updatedCircles)
  }
  function deleteCircle() {
    let newCircles = circles.filter((ele) => {
      return ele.isSelected !== true
    })
    setCircles(newCircles)
  }
  return (
    <div>
      <div style={{ display: "flex", gap: "40px", justifyContent: "center" }}>
        <button
          style={{ backgroundColor: "green", padding: "20px 30px", color: "white" }}
          onClick={createCircle}
        >
          CREATE CIRCLE
        </button>
        <button
          style={{ backgroundColor: "red", padding: "20px 30px", color: "white" }}
          onClick={deleteCircle}
        >
          DELETE CIRCLE
        </button>
      </div>
      <div style={{ display: "flex", gap: "40px", justifyContent: "center" }}>
        <h1>total no of circles: {circles.length}</h1>
        <h1>total no of selected circles: {circles.filter((ele) => ele.isSelected).length}</h1>
      </div>
      <div
        className="circles"
        style={{ display: "flex", flexWrap: "wrap", gap: "20px" }}
      >
        {circles.map((ele) => {
          return (
            <div
              key={ele.id}
              className="circle"
              style={{
                height: "120px",
                width: "120px",
                border: "1px solid red",
                background: ele.isSelected ? "red" : "green",
                borderRadius: "50%",
              }}
              onClick={() => selectCircle(ele.id)}
            ></div>
          );
        })}
      </div>
    </div>

  )
}

export default CircleCreate