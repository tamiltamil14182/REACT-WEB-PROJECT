// import React from 'react'

function ArrayData() {
    let fruits=['apple','banana','mango','orange','grapes']
   
  return (
    <div>
       {fruits.map((ele,i)=>{
         return <li key={i}>{ele}</li>
       })}
    </div>
  )
}

export default ArrayData