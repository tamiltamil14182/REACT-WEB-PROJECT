import { useState } from "react"

function ColorChange() {
    const [color,setColor]=useState("")
  return (
    <div style={{height:"250px",width:"300px",border:"1px solid black",margin:"auto",
        alignContent:"center",textAlign:"center",backgroundColor:color
       }}>
           
           <input type="text" onChange={(event)=> setColor(event.target.value)} value={color}/>
      </div>
  )
}

export default ColorChange