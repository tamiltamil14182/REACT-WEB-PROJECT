import { useState } from "react"

function ArrayFruits() {
    const [text,setText]=useState("")
    const [fruits,setFruits]=useState([])
    const handleChange=(event)=>{
      setText(event.target.value)
    }
    function addFruits(){
      setFruits([...fruits,text])
      setText("")
    }
  return (
    <>
    <div>
      <input type="text" placeholder="write the fruit names..." onChange={handleChange} value={text}/>
      <button onClick={addFruits}>ADD</button>
    </div>

    <div>
      <h1>All Fruits List...</h1>
      {
        fruits.map((ele,i)=>{
          return <li key={i}>{ele}</li>
        })
      }  
    </div>
    </>
    )
}

export default ArrayFruits