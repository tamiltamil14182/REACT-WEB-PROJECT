import { useState } from "react"

function TextCount() {
    const [text, setText] = useState("");

    const handleTextChange = (event) => {
      const updatedText = event.target.value;
      setText(updatedText);
    };
  
    const clearText = () => {
      setText("");
    };
  
    const toUpperCase = () => {
      setText(text.toUpperCase());
    };
  
  
    const backspaceText = () => {
      setText(text.slice(0, -1));
    };
    
  return (
    <div>
      <textarea name="" id="" value={text} style={{
        border:"1px solid black",height:"100px",width:"200px",margin:"auto",
        placeItems:"center",placeContent:"center"}} onChange={handleTextChange}>
      </textarea>

      <div style={{ display: "flex", gap: "40px",wordSpacing:"3px"}}>
      <h1>No Of Chars :{text.length}</h1>
      <h1>No Of Word :{text.split(/\s+/).filter(Boolean).length}</h1>
      </div>

          <div style={{ display: "flex",width:"500px"}}>
        <button style={{marginRight:"10px",fontSize:"30px"}} onClick={clearText}><b>Clear</b></button>
        <button style={{marginRight:"10px",fontSize:"30px"}} onClick={toUpperCase}><b>Uppercase</b></button>
        <button style={{marginRight:"10px",fontSize:"30px"}} onClick={backspaceText}><b>Backspace</b></button>
      </div>
    </div>
  )
}

export default TextCount