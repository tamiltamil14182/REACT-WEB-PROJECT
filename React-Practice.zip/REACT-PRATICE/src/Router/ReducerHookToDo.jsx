import { useReducer } from "react";

const initialState = {
  text: "",
  todo: [],
};

function reducer(state, action) {
  if (action.type === "SET_TEXT") {
    return { ...state, text: action.payload };
  } else if (action.type === "ADD_TASK") {
    const newTask = {
      task: state.text,
      id: Math.trunc(Math.random() * 10000),
    };
    return { ...state, todo: [...state.todo, newTask], text: "" };
  } else if (action.type === "DELETE_TASK") {
    return { ...state, todo: state.todo.filter(task => task.id !== action.payload) };
  } else if (action.type === "EDIT_TASK") {
    return {
      ...state,
      todo: state.todo.map(task =>
        task.id === action.payload.id ? { ...task, task: action.payload.newTask } : task
      ),
    };
  } else {
    return state;
  }
}


function ReducerHookToDo() {

  const [state, dispatch] = useReducer(reducer, initialState);

  function handleChange(e) {
    dispatch({ type: "SET_TEXT", payload: e.target.value });
  }

  function addTask() {
    dispatch({ type: "ADD_TASK" });
  }

  function deleteTask(id) {
    dispatch({ type: "DELETE_TASK", payload: id });
  }

  function editTask(id, newTask) {
    dispatch({ type: "EDIT_TASK", payload: { id, newTask } });
  }

  return (
    <div className="container bg-light">
      <h1 className="text-center fs-2">TODO LIST</h1>
      <div className="input-group input-group-lg">
        <input
          type="text"
          className="form-control"
          aria-describedby="inputGroup-sizing-lg"
          onChange={handleChange} // Handle input change
          value={state.text} // Bound to state value
        />
        <button
          className="mx-2 px-4 py-2 fs-3 bg-success text-white rounded"
          onClick={addTask} // Add task
        >
          Add
        </button>
      </div>
      <div className="container d-flex flex-column">
        {state.todo.map((task) => (
          <div
            key={task.id}
            className="border border-secondary w-100 mb-2 d-flex p-2"
          >
            <h1 className="flex-grow-1 fs-4">{task.task}</h1>
            <button
              className="bg-info px-3 py-1 text-white mx-2"
              onClick={() => editTask(task.id, prompt("Edit task:", task.task))} // Edit task
            >
              Edit
            </button>
            <button
              className="bg-info px-3 py-1 text-white mx-2"
              onClick={() => deleteTask(task.id)} // Delete task
            >
              Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ReducerHookToDo;
