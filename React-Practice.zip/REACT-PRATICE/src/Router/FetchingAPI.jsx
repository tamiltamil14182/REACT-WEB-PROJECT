import { useState, useEffect } from "react"

function FetchingAPI() {
    const url = "https://jsonplaceholder.typicode.com/users"
    const [data, setData] = useState([])

    // useEffect(()=>{
    //     fetch(url)
    //     .then(Response=>Response.json())
    //     .then(data=>setData(data))
    //     .catch(error=>{console.log(error)})
    // })

    useEffect(() => {
        const getData = async () => {
            try {
                const response = await fetch(url)
                const data = await response.json()
                setData(data)
            }
            catch (error) {
                console.log(error)
            }
        }
        getData()
    }, []);

    return (
        <>
            <h1>Fetching Data From Server</h1>
            <table border={1} cellPadding={10}>
                <thead style={{textAlign:"center"}}>
                    <tr>
                        <th>ID</th>
                        <th>NAME</th>
                        <th>USERNAME</th>
                        <th>EMAIL</th>
                        <th>PHONE</th>
                    </tr>
                </thead>

                <tbody style={{textAlign:"center"}}>
                    {data.map((ele) => (
                        <tr key={ele.id}>
                            <td>{ele.id}</td>
                            <td>{ele.name}</td>
                            <td>{ele.username}</td>
                            <td>{ele.email}</td>
                            <td>{ele.phone}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </>
    )
}

export default FetchingAPI