import { useState } from "react";

function StateHookToDo() {
  const [text, setText] = useState("");
  const [todo, setTodo] = useState([]);

  function addTask() {
    let obj = {
      task: text,
      id: Math.trunc(Math.random() * 10000),
    };
    setTodo([...todo, obj]);
    setText("");
  }

  function deleteTask(id) {
    let updateTodo = todo.filter((ele) => ele.id != id);
    setTodo(updateTodo);
  }

  function editTask(id, newTask) {
    setTodo(
      todo.map((task) => (task.id === id ? { ...task, task: newTask } : task))
    );
  }

  return (
    <div className="container bg-light">
      <h1 className="text-center fs-2">TODO LIST</h1>
      <div className="input-group input-group-lg">
        <input
          type="text"
          className="form-control"
          aria-describedby="inputGroup-sizing-lg"
          onChange={(e) => setText(e.target.value)}
          value={text}
        />
        <button
          className="mx-2 px-4 py-2 fs-3 bg-success text-white rounded"
          onClick={addTask}
        >
          Add
        </button>
      </div>
      <div className="container d-flex flex-column">
        {todo.map((task) => (
          <div
            key={task.id}
            className="border border-secondary w-100 mb-2 d-flex p-2"
          >
            <h1 className="flex-grow-1 fs-4">{task.task}</h1>
            <button
              className="bg-info px-3 py-1 text-white mx-2"
              onClick={() => editTask(task.id, prompt("Edit task:", task.task))}
            >
              Edit
            </button>
            <button
              className="bg-info px-3 py-1 text-white mx-2"
              onClick={() => deleteTask(task.id)}
            >
              Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default StateHookToDo;