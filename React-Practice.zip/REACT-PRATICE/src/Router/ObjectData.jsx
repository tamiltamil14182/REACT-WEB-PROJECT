import { useState } from "react"

function ObjectData() {
    const [object]=useState({
        name:"Tamil",
        age:21,
        city:"Erode"
    })
  return (

    <div>
        <h1>Object Data</h1>
        <p>Name : {object.name}</p>
        <p>Age : {object.age}</p>
        <p>city : {object.city}</p>
    </div>
  )
}

export default ObjectData