import { useState } from "react";

function ChangeWordPosition() {
  const [text, setText] = useState(""); // State for input text
  const [names, setNames] = useState(["Add Top","Add Bottom"]); // State for storing the list of words

  function addTop() {
    setNames([text, ...names]); // Adds the text at the top
    setText(""); // Clears the input field
  }

  function addBottom() {
    setNames([...names, text]); // Adds the text at the bottom
    setText(""); // Clears the input field
  }

  return (
    <>
      <div>
        <input
          type="text"
          placeholder="Write Your Text"
          onChange={(e) => setText(e.target.value)} // Corrected to use e.target.value
          value={text}
        />
        <button onClick={addTop}>ADD TOP</button>
        <button onClick={addBottom}>ADD BOTTOM</button>
      </div>

      <div>
        <h1>Add Text</h1>
        <ul>
          {
            names.map((text, i) => { // Corrected map parameters
              return <li key={i}>{text}</li>; // Render list items
            })
          }
        </ul>
      </div>
    </>
  );
}

export default ChangeWordPosition;
