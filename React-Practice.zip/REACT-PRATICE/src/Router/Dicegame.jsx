import { useState } from "react"

function Dicegame() {
    const [option, setOption] = useState("")
    const [lucknum, setLuckyNum] = useState(null)
    const handelChoices = (event) => {
        setLuckyNum(null)
        setOption(event.target.value)
    }
    const play = () => {
        setTimeout(() => {
            let randomValue = Math.floor((Math.random() * 10) + 2)
            setLuckyNum(randomValue)
        }, 2000)
    }
    function isWon() {
        if (option == "small") {
            if (lucknum >= 2 && lucknum <= 6) {
                return true;
            }
            else {
                return false
            }
        }
        else if (option == "big") {
            if (lucknum >= 8 && lucknum <= 12) {
                return true;
            }
            else {
                return false
            }
        }
        else if (option == "jackpot") {
            if (lucknum === 7) {
                return true;
            }
            else {
                return false
            }
        }
    }
    return (
        <div className="container">
            <h1>DICE GAME</h1>
            <div>
                <img src="https://media.istockphoto.com/id/1336400835/vector/cartoon-dice-vector-illustration-on-white-background.jpg?s=612x612&w=0&k=20&c=MfAZZeS5B6eU25J-72mG8Ar-BDAZJgeIPV2jXBr-zjI="
                    alt="dice" height={"100px"} width={"100px"} />
            </div>
            <div className="buttons">
                <div className="option">
                    <input type="radio" name="choice" value={"small"} id="choice1" onChange={handelChoices} />
                    <label htmlFor="choice1">Small 2-6</label>
                </div>
                <div className="option">
                    <input type="radio" name="choice" value={"jackpot"} id="choice2" onChange={handelChoices} />
                    <label htmlFor="choice2">Jackpot 7</label>
                </div>
                <div className="option">
                    <input type="radio" name="choice" value={"big"} id="choice3" onChange={handelChoices} />
                    <label htmlFor="choice3">Big 8-12</label>
                </div>
            </div>
            <div className="bet-info">
                {option ?
                    <h1>You have bet for <span>{option}</span></h1> :
                    <h1>Select your option to start</h1>}

            </div>
            <div className="play-btn">
                {option && <button onClick={play}>PLAY</button>}
            </div>
            <div className="lucky-num">
                {option && <h1>Lucky Number 👉 <span>{lucknum}</span></h1>}
            </div>
            {
                lucknum && <div className="result">
                    {
                        isWon() ? <h1 className="won">Congratulation You Won 🎉🎊</h1> :
                            <h1 className="lost">Oooops Better Luck Next Time 👹</h1>
                    }
                </div>
            }
        </div>
    )
}
export default Dicegame;