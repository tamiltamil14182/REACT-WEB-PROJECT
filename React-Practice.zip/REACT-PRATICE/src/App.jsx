// import FetchingAPI from './API Server Data/FetchingAPI'
// import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom';

// import Login from './Router/Login'
// import Navbar from './Router/Navbar'
import ArrayData from './Router/ArrayData';
import ObjectData from './Router/ObjectData';
import CircleCreate from './Router/CircleCreate';
import ColorChange from './Router/ColorChange';
import TextCount from './Router/TextCount';
import ArrayFruits from './Router/ArrayFruits';
import ChangeWordPosition from './Router/ChangeWordPosition';
import Dicegame from './Router/Dicegame';
import AddNewData from './Router/AddNewData';
import ImageData from './Router/ImageData';
import FetchingAPI from './Router/FetchingAPI';
import FetchingDataAxios from './Router/FetchingDataAxios';
import OddEvenPrimeNum from './Router/OddEvenPrimeNum';
import AllHomeComponent from './Router/AllHomeComponent';
import ReducerHookToDo from './Router/ReducerHookToDo';
import StateHookToDo from './Router/StateHookToDoList';
import CountReducer from './Router/CountReducer';

function App() {
  return (
    <>
      {/* 
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div> 
      */}
      
      <BrowserRouter>
        <div>
          <Routes>
            <Route path="/" element={<AllHomeComponent/>} />
            <Route path="/array-data" element={<ArrayData/>}></Route>
            <Route path="/object-data" element={<ObjectData/>}></Route>
            <Route path="/image-data" element={<ImageData/>}></Route>
            <Route path="/circle-create" element={<CircleCreate/>}></Route>
            <Route path="/color-change" element={<ColorChange/>}></Route>
            <Route path="/text-count" element={<TextCount/>}></Route>
            <Route path="/array-fruits" element={<ArrayFruits/>}></Route>
            <Route path="/change-word-position" element={<ChangeWordPosition/>}></Route>
            <Route path="/dicegame" element={<Dicegame/>}></Route>
            <Route path="/statehook-todo" element={<StateHookToDo/>}></Route>
            <Route path="/add-new-data" element={<AddNewData/>}></Route>
            <Route path="/array-fruits" element={<ArrayFruits/>}></Route>
            <Route path="/fetching-api" element={<FetchingAPI/>}></Route>
            <Route path="/fetching-data-axios" element={<FetchingDataAxios/>}></Route>
            <Route path="/odd-even-prime-num" element={<OddEvenPrimeNum/>}></Route>
            <Route path="/reducerhook-todo" element={<ReducerHookToDo/>}></Route>
            <Route path="/count-reducer" element={<CountReducer/>}></Route>
          </Routes>
        </div>
      </BrowserRouter>
    </>
  );
}

export default App;
